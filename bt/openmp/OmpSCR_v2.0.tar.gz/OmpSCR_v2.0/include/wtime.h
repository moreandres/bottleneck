/*
* OpenMP Source Code Repository
*
* Wrapper to a system dependent clock function
*
*/
double OSCR_wtime();

