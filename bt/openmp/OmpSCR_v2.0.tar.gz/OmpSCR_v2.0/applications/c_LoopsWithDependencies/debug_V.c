/* 6. WRITE MATRIX (DEBUG) */
{
int i;
fprintf(stderr,"Vector: V -----------------\n");
for (i=0; i<totalSize; i++) {
	fprintf(stderr,"%6.2f\n", V[i]);
	}
}

